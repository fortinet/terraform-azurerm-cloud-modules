import requests
import time
import base64
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from .utils import *
from urllib.parse import quote, unquote

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)


class FortiGateConfig:
    """
    This class is used to communicate with FGT through https port.
    """

    def __init__(
        self,
        host_ip,
        instance_id,
        login_port="",
        username="admin",
        password="",
        debug=True,
    ):
        self.host_ip = host_ip
        self.login_port = str(login_port)
        self.cookie = ""
        self.csrf_token = ""
        self.instance_id = instance_id
        self.timeout_sec = 10
        # Specify user/passwd in the beginning, so it is easy to relogin.
        self.username = username
        self.password = self.quote_as_needed(password)
        self.debug = debug

    def send_one_request(
        self, url, header, data={}, request_name="", attempt_time=0, method="post"
    ):
        response = requests.Response()
        self._log(
            "Task {} | Attempt {} Request | URL {} | Header {}".format(
                request_name,
                attempt_time,
                url,
                header,
            )
        )
        try:
            if method == "post":
                response = requests.post(
                    url,
                    headers=header,
                    json=data,
                    verify=False,
                    timeout=self.timeout_sec,
                )
            elif method == "get":
                response = requests.get(
                    url,
                    headers=header,
                    json=data,
                    verify=False,
                    timeout=self.timeout_sec,
                )
            self._log(
                "Task {} | Attempt {} Response | Code {} | Text {} | Header {}".format(
                    request_name,
                    attempt_time,
                    response.status_code,
                    str(response.text).replace("\n", ""),
                    str(response.headers).replace("\n", ""),
                )
            )
        except Exception as e:
            self._log(
                "Task {} | Attempt {} Fail, {}.".format(request_name, attempt_time, e)
            )
        return response

    def send_request(
        self,
        url,
        header,
        data={},
        request_name="",
        max_attempt=3,
        sleep_time=20,
        success_rc=[200],
        relogin_rc=[401],
    ):
        attempt_time = 0
        response = requests.Response()
        while attempt_time <= max_attempt and response.status_code not in success_rc:
            attempt_time += 1
            if request_name not in [
                "login",
                "change_password",
                "change_password_logout",
            ]:
                header["Cookie"] = self.cookie
                header["X-CSRFTOKEN"] = self.csrf_token
            response = self.send_one_request(
                url, header, data, request_name, attempt_time
            )
            if attempt_time == max_attempt or response.status_code in success_rc:
                break
            self._log(
                f"Task {request_name} | Attempt {attempt_time} | Sleep {sleep_time}s and retry"
            )
            time.sleep(sleep_time)
            # If relogin_rc (usually 401), try to login again and get new cookie
            if response.status_code in relogin_rc:
                self._log(
                    "Task {} | Attempt {} | Login again due to last request was {}".format(
                        request_name, attempt_time, response.status_code
                    )
                )
                self.login()
        return response.status_code in success_rc, response

    def get_url(self, path):
        login_port = ""
        if self.login_port:
            login_port = ":" + self.login_port
        if not path.startswith("/"):
            path = "/" + path
        return "https://" + self.host_ip + login_port + path

    def quote_as_needed(self, data):
        """
        Quote the data if it is a string, otherwise return it as is.
        This is used to ensure that the password is properly encoded.
        """
        if isinstance(data, str) and data == unquote(data):
            return quote(data)
        return data

    def login(self, username="", password=""):
        if not username:
            username = self.username
        if not password:
            password = self.password
        else:
            password = self.quote_as_needed(password)
        LOGIN_FORMAT = "logincheck?username={username}&secretkey={password}"
        url = self.get_url(LOGIN_FORMAT.format(username=username, password=password))
        header = {"Content-Type": "application/json"}
        status, response = self.send_request(
            url, header, request_name="login", relogin_rc=[]
        )
        if response.status_code != 200:
            self._log("Cannot login {}".format(response.text))
            return False, response
        self._get_cookie_from_headers(response.headers)
        return status, response

    def upload_license(self, license_source, license_data):
        if license_source not in ["fortiflex", "file"]:
            return False, self._generate_response(
                "variable LICENSE_SOURCE should be 'fortiflex' or 'file'."
            )
        status, response = self.login()
        if not status:
            return False, response
        header = {"Content-Type": "application/json"}
        if license_source == "fortiflex":
            body = {"token": license_data}
            url = self.get_url("/api/v2/monitor/system/vmlicense/download")
            status, response = self.send_request(
                url,
                header,
                data=body,
                request_name="upload_license_fortiflex",
                success_rc=[200, 500],
            )
            if (
                response.status_code == 500
                and "License Token is already used" in response.text
            ):
                return True, response
            return status, response
        elif license_source == "file":
            body = {"file_content": self._base64_encode(license_data)}
            url = self.get_url("/api/v2/monitor/system/vmlicense/upload")
            return self.send_request(
                url, header, data=body, request_name="upload_license_file"
            )
        return False, requests.Response()

    def upload_config(self, config_data, config_name="config_data.conf"):
        status, response = self.login()
        if not status:
            return False, response
        header = {"Content-Type": "application/json"}
        encoded_config_data = self._base64_encode(config_data)
        body = {"filename": config_name, "file_content": encoded_config_data}
        url = self.get_url("/api/v2/monitor/system/config-script/upload")
        status, response = self.send_request(
            url, header, data=body, request_name="upload_config"
        )
        return status, response

    def change_init_password(self, old_password, new_password):
        url = self.get_url("/api/v2/authentication")
        header = {"Content-Type": "application/json"}
        body = {
            "username": "admin",
            "secretkey": old_password,
            "ack_pre_disclaimer": True,
            "ack_post_disclaimer": True,
            "new_password1": new_password,
            "new_password2": new_password,
            "request_key": True,
        }
        attempt_time = 0
        max_attempt = 5
        response = requests.Response()
        session_key = ""
        while attempt_time <= max_attempt:
            attempt_time += 1
            response = self.send_one_request(
                url,
                header,
                data=body,
                request_name="change_password",
                attempt_time=attempt_time,
            )
            if response.status_code == 200:
                response_json = response.json()
                session_key = response_json.get("session_key", "")
                if session_key:
                    break
            time.sleep(20)
        if not session_key:
            self._log(
                "can't get session key when changing password {}".format(response_json)
            )
            return False, response
        body = {"session_key": session_key}
        self.send_request(
            url,
            header,
            data=body,
            request_name="change_password_logout",
            max_attempt=1,
            success_rc=[200, 500],
        )
        return True, response

    def _generate_response(self, response_text):
        response = requests.Response()
        response._content = response_text.encode("utf-8")
        response.encoding = "utf-8"
        return response

    def _get_cookie_from_headers(self, header):
        cookie_data = ""
        for key in header:
            if key.lower() == "set-cookie":
                cookie_data = header[key]
                break
        cookie_list = cookie_data.split(",")
        cookie_list = [item.split(";")[0] for item in cookie_list]
        for item in cookie_list:
            if "ccsrftoken" in item:
                self.csrf_token = item.split('"')[1]
        self.cookie = ";".join(cookie_list)

    def _base64_encode(self, data):
        if not isinstance(data, bytes):
            data = str(data).encode("ascii")
        return base64.b64encode(data).decode("ascii")

    def _log(self, error_str):
        if self.debug:
            debug_print("[{}] {}".format(self.instance_id, error_str))
