# from google.cloud import firestore
import json
import os
from azure.storage.blob import BlobClient
from azure.core.exceptions import ResourceNotFoundError
from .utils import debug_print


class StorageWrapper:
    def __init__(self, storage_url):
        self.current_lease = None

        self.blob_url = storage_url.get_blob_url()
        blob_client = BlobClient.from_blob_url(self.blob_url)

        try:
            # Check if the blob exists
            print('blob url', self.blob_url)
            blob_client.get_blob_properties()
        except ResourceNotFoundError:
            blob_client.upload_blob("{}")
        except Exception as e:
            debug_print(f"error getting blob property for {self.blob_url}: {e}")
            raise e

    def _get_blob_client(self):
        return BlobClient.from_blob_url(self.blob_url)

    def _get_lease_id(self):
        return self.current_lease.id if self.current_lease else None

    def get_document(self, document_name):
        blob_client = self._get_blob_client()
        config = json.loads(blob_client.download_blob().readall())

        if document_name in config:
            return config[document_name]

        return None

    def add_document(self, document_name, data):
        blob_client = self._get_blob_client()
        config = json.loads(blob_client.download_blob().readall())

        if not document_name in config:
            config[document_name] = data
            blob_client.upload_blob(
                json.dumps(config), overwrite=True, lease=self._get_lease_id()
            )

    def set_document(self, document_name, data):
        blob_client = self._get_blob_client()
        config = json.loads(blob_client.download_blob().readall())
        config[document_name] = data
        blob_client.upload_blob(
            json.dumps(config), overwrite=True, lease=self._get_lease_id()
        )

    def update_document(self, document_name, new_data):
        blob_client = self._get_blob_client()
        config = json.loads(blob_client.download_blob().readall())

        config[document_name] = {**config[document_name], **new_data}
        blob_client.upload_blob(
            json.dumps(config), overwrite=True, lease=self._get_lease_id()
        )

    def delete_document(self, document_name):
        blob_client = self._get_blob_client()
        config = json.loads(blob_client.download_blob().readall())
        if document_name in config:
            del config[document_name]
            blob_client.upload_blob(
                json.dumps(config), overwrite=True, lease=self._get_lease_id()
            )

    def get_document_number(self):
        blob_client = self._get_blob_client()
        config = json.loads(blob_client.download_blob().readall())

        return len(config)

    def get_all_documents(self):
        blob_client = self._get_blob_client()
        return json.loads(blob_client.download_blob().readall())

    def lock(self, document_name):
        if self.current_lease:
            return False, None

        blob_client = BlobClient.from_blob_url(self.blob_url)
        self.current_lease = blob_client.acquire_lease(lease_duration=60)
        config = json.loads(blob_client.download_blob().readall())
        debug_print("lease acquired")
        return True, config[document_name]

    def unlock(self, document_name):
        if not self.current_lease:
            return True

        self.current_lease.release()
        self.current_lease = None
        debug_print("lease released")
        return True


class StorageUrl:
    def __init__(self, account_name, container_name, blob_name, sas_config) -> None:
        self.account_name = account_name
        self.container_name = container_name
        self.blob_name = blob_name
        self.sas_config = sas_config

    def get_container_url(self):
        return f"https://{self.account_name}.blob.core.windows.net/{self.container_name}{self.sas_config}"

    def get_blob_url(self):
        return f"https://{self.account_name}.blob.core.windows.net/{self.container_name}/{self.blob_name}{self.sas_config}"


def download_license_file(file_path) -> str:
    account_name = os.getenv("STORAGE_ACCOUNT_NAME")
    countainer_name = os.getenv("STORAGE_CONTAINER_NAME")
    sas_config = os.getenv("STORAGE_SAS_CONFIG")

    url_obj = StorageUrl(account_name, countainer_name, file_path, sas_config)

    blob_client = BlobClient.from_blob_url(url_obj.get_blob_url())
    return blob_client.download_blob().readall()
