import os
import re
import logging

logging.basicConfig(
    level=logging.INFO,  # Set the logging level to INFO
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()],  # Log to the console (standard output)
)

logger = logging.getLogger("azure")
logger.setLevel(logging.ERROR)


PRINT_DEBUG_INFO = True


def debug_print(print_str):
    if PRINT_DEBUG_INFO:
        logging.info(print_str.replace("\n", "\\n"))


def get_key_from_url(url, key):
    match = re.search(key + "/([^/]+)", url)
    if match:
        return match.group(1)
    return ""
