import sys
import os

sys.path.append(os.path.abspath(".python_packages/lib/site-packages"))

import logging
import time
import json
import azure.functions as func
from azure.identity import DefaultAzureCredential
from azure.mgmt.compute import ComputeManagementClient
from azure.mgmt.network import NetworkManagementClient
from azure.storage.blob import ContainerClient
from retry import retry

from .fortiflex import FortiFlex
from .fortigate import (
    FortiGateConfig,
)
from .storage import (
    StorageUrl,
    StorageWrapper,
    download_license_file,
)
from .utils import *

# General param
LICENSE_SOURCE = os.getenv("FORTIGATE_LICENSE_SOURCE", "file_fortiflex")
FORTIGATE_INSTANCE_USER_NAME = os.getenv("FORTIGATE_INSTANCE_USER_NAME")
FORTIGATE_INSTANCE_PASSWORD = os.getenv("FORTIGATE_INSTANCE_PASSWORD")
AUTOSCALE_PSKSECRET = os.getenv("AUTOSCALE_PSKSECRET")
MANAGEMENT_PORT = os.getenv("MANAGEMENT_PORT", 443)

# Foriflex param
FORTIFLEX_CONFIG_ID = os.getenv("FORTIFLEX_CONFIG_ID")
FORTIFLEX_USERNAME = os.getenv("FORTIFLEX_USERNAME")
FORTIFLEX_PASSWORD = os.getenv("FORTIFLEX_PASSWORD")
FORTIFLEX_RETRIEVE_MODE = os.getenv("FORTIFLEX_RETRIEVE_MODE", "use_stopped")
FORTIFLEX_CONCURRENT_MODE = os.getenv("FORTIFLEX_CONCURRENT_MODE", False)

STORAGE_ACCOUNT_NAME = os.getenv("STORAGE_ACCOUNT_NAME")
STORAGE_CONTAINER_NAME = os.getenv("STORAGE_CONTAINER_NAME")
STORAGE_SAS_CONFIG = os.getenv("STORAGE_SAS_CONFIG")
STORAGE_CONFIG_FILE_NAME = "config_data"

STORAGE_URL = StorageUrl(
    STORAGE_ACCOUNT_NAME,
    STORAGE_CONTAINER_NAME,
    STORAGE_CONFIG_FILE_NAME,
    STORAGE_SAS_CONFIG,
)

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)


def main(req: func.HttpRequest) -> func.HttpResponse:
    debug_print(f"received req with data {str(req.get_body())}")

    new_capacity = -1
    try:
        json_body = req.get_json()
        new_capacity = json_body["context"]["newCapacity"]
    except Exception as ex:
        debug_print(f"failed to get new capacity, skipping capacity check: {ex}")

    run_license_refresh_cycle(new_capacity)

    storageClient = StorageWrapper(STORAGE_URL)
    return func.HttpResponse(
        body=json.dumps(
            {
                "latest_mappings": storageClient.get_all_documents(),
            }
        ),
        status_code=200,
        mimetype="application/json",
    )


def run_license_refresh_cycle(new_capacity):
    storageClient = StorageWrapper(STORAGE_URL)
    # 1. load global license status

    init_global_license_file_status(storageClient)
    existing_instances = storageClient.get_all_documents()
    debug_print(f"Current file license mappings: {existing_instances}")

    # 2. load all active instance ips: get_latest_public_ips
    latest_instances = get_latest_instances(new_capacity)
    debug_print(f"Latest VMSS instance details: {latest_instances}")

    # 3. assign free licenses/tokens for new ips
    insert_count = 0
    delete_count = 0
    for instance_id, instance_info in existing_instances.items():
        if instance_id == "GLOBAL" or instance_id in latest_instances:
            continue
        debug_print(f"{instance_id} no longer exists, deleting the license mapping")
        wrapper = FunctionWrapper(instance_info, storageClient)
        wrapper.instance_delete()
        delete_count += 1

    for instance_id, instance_info in latest_instances.items():
        if (
            instance_id in existing_instances
            and "license_source" in existing_instances[instance_id]
        ):
            continue
        debug_print(
            f"{instance_id} is just created or is not licensed, assigning a license"
        )
        wrapper = FunctionWrapper(instance_info, storageClient)
        wrapper.instance_insert()
        insert_count += 1

    debug_print(
        f"Finished processing with {insert_count} new instance(s), {delete_count} removed instance(s)."
    )

    ## Reselect master if needed or it will be called after a scale-in event
    for instance_id, instance_info in storageClient.get_all_documents().items():
        if instance_id == "GLOBAL":
            continue
        if "auto-scale" not in instance_info or not instance_info["auto-scale"]:
            wrapper = FunctionWrapper(instance_info, storageClient)
            ## only need to run once for all instances
            wrapper.reselect_master()
            debug_print(f"Finished patch auto-scale settings")

            break


def init_global_license_file_status(storageClient):
    container = ContainerClient.from_container_url(STORAGE_URL.get_container_url())
    license_key = "license_file_status"
    global_config = storageClient.get_document("GLOBAL")
    if not global_config:
        storageClient.set_document("GLOBAL", {})
        global_config = storageClient.get_document("GLOBAL")

    license_file_status = (
        global_config[license_key] if license_key in global_config else {}
    )
    blobs = container.list_blobs()
    for blob in blobs:
        file_path = blob.name
        if file_path.startswith("licenses/") and file_path not in license_file_status:
            license_file_status[file_path] = ""
    storageClient.update_document("GLOBAL", {license_key: license_file_status})

    return license_file_status


@retry(Exception, tries=10, delay=1, backoff=2, max_delay=4)
def get_latest_instances(new_capacity) -> dict[str, dict]:
    """Get the latest instance list and parse for private ip for auto scale and public ip for uploading license
    When the public ip is not available for an instance, it means the instance is not ready yet so the function
    retries with backoff up to 10 times up to 1 minute.
    """
    # Retrieve environment variables
    subscription_id = os.environ["AZURE_SUBSCRIPTION_ID"]
    resource_group_name = os.environ["RESOURCE_GROUP_NAME"]
    vmss_name = os.environ["VMSS_NAME"]

    # Authenticate with Managed Identity
    credential = DefaultAzureCredential()

    network_client = NetworkManagementClient(
        credential, subscription_id, api_version="2023-09-01"
    )

    compute_client = ComputeManagementClient(credential, subscription_id)
    vm_instances = compute_client.virtual_machine_scale_set_vms.list(
        resource_group_name,
        vmss_name,
    )

    instance_details = {}

    for vm in vm_instances:
        network_interfaces = network_client.network_interfaces.list_virtual_machine_scale_set_vm_network_interfaces(
            resource_group_name,
            vmss_name,
            vm.instance_id,
        )
        instance_details[vm.name] = {
            "instance_id": vm.name,
        }

        for nic in network_interfaces:
            if nic.ip_configurations:
                for ip_config in nic.ip_configurations:
                    if ip_config.private_ip_address:
                        instance_details[vm.name][
                            "private_ip"
                        ] = ip_config.private_ip_address

                    addresses = network_client.public_ip_addresses.list_virtual_machine_scale_set_vm_public_ip_addresses(
                        resource_group_name,
                        vmss_name,
                        vm.instance_id,
                        nic.name,
                        ip_config.name,
                    )

                    for addr in addresses:
                        if addr.ip_address:
                            instance_details[vm.name]["management_ip"] = addr.ip_address
                            break

        if "management_ip" not in instance_details[vm.name]:
            raise Exception(
                f"instance {vm.name} does not have public_ip yet: {instance_details[vm.name]}"
            )
        if new_capacity >= 0 and len(instance_details) != new_capacity:
            raise Exception(
                f"Autoscale has not finished changing instances, expecting new capacity {new_capacity}, found {len(instance_details)} instances"
            )
    return instance_details


class FunctionWrapper:
    def __init__(self, instance_info, storageClient):
        self.instance_id = instance_info["instance_id"]
        self.management_ip = instance_info["management_ip"]
        self.private_ip = instance_info["private_ip"]
        self.db = storageClient

    def instance_insert(self):
        """
        Update database, inject license when new instance is created.
        """
        primary_sync_ip = ""
        is_master = False
        timestamp = time.time()

        # Updata database
        # management_ip = instance.network_interfaces[0].network_i_p
        # Get global data
        global_data = self.db.get_document("GLOBAL")
        if "primary_sync_ip" not in global_data:
            is_master = True
            primary_sync_ip = self.private_ip
            global_data = {
                "primary_sync_ip": primary_sync_ip,
                "primary_instance_id": self.instance_id,
                "license_source": LICENSE_SOURCE,
            }
            self.db.update_document("GLOBAL", global_data)
        else:
            primary_sync_ip = global_data["primary_sync_ip"]

        instance_data = {
            "instance_id": self.instance_id,
            "is_master": is_master,
            "management_ip": self.management_ip,
            "private_ip": self.private_ip,
            "management_port": MANAGEMENT_PORT,
            "timestamp": timestamp,
        }
        self.db.add_document(self.instance_id, instance_data)
        config_module = FortiGateConfig(
            self.management_ip,
            self.instance_id,
            login_port=MANAGEMENT_PORT,
            debug=PRINT_DEBUG_INFO,
            username=FORTIGATE_INSTANCE_USER_NAME,
            password=FORTIGATE_INSTANCE_PASSWORD,
        )

        # Upload license
        status, response = None, None
        if LICENSE_SOURCE in ["fortiflex", "file", "file_fortiflex"]:
            if LICENSE_SOURCE in ["file", "file_fortiflex"]:
                status, license_data = self.file_license_assign()
                if status:
                    status, response = config_module.upload_license(
                        "file", license_data
                    )
            if LICENSE_SOURCE == "fortiflex" or (
                LICENSE_SOURCE == "file_fortiflex" and not status
            ):
                foritflex = FortiFlex(
                    username=FORTIFLEX_USERNAME,
                    password=FORTIFLEX_PASSWORD,
                    task_name="AZURE:" + self.instance_id,
                )
                entitlement = foritflex.retrieve_unused_entitlement(
                    FORTIFLEX_CONFIG_ID,
                    mode=FORTIFLEX_RETRIEVE_MODE,
                    concurrent_mode=FORTIFLEX_CONCURRENT_MODE,
                )
                status = entitlement != {}
                if status:
                    license_data = entitlement["token"]
                    self.debug_print(
                        f"uploading license from entitlement {entitlement}"
                    )
                    status, response = config_module.upload_license(
                        "fortiflex", license_data
                    )

                    if status:
                        self.db.update_document(
                            self.instance_id,
                            {
                                "serial_number": entitlement["serialNumber"],
                                "config_id": entitlement["configId"],
                                "license_source": "fortiflex",
                            },
                        )

                else:
                    self.debug_print(
                        "No available fortiflex token can be used. Host will be unlicensed"
                    )
            self.debug_print(f"Upload license {status} {response}")

            if not status:
                self.debug_print("License injection fail, return")
                return
            self.debug_print("Wait FGT reboot, sleep 80s")
            time.sleep(80)

            config_data = config_system_autoscale(
                is_master, primary_sync_ip, AUTOSCALE_PSKSECRET
            )
            self.debug_print(
                f"config auto-scaling for {self.instance_id}, primary? {is_master}: {config_data}"
            )
            status, response = config_module.upload_config(config_data)
            self.debug_print(f"Config auto-scaling result {status}, {response}")
            if status:
                self.db.update_document(self.instance_id, {"auto-scale": True})

    def instance_delete(self):
        """
        Update database, release license when instance is deleted.
        """
        instance_data = self.db.get_document(self.instance_id)
        if instance_data is None:
            instance_data = {}
        license_source = instance_data.get("license_source", "")
        if license_source == "fortiflex":  # Release fortiflex token
            config_id = instance_data.get("config_id", "")
            serial_number = instance_data.get("serial_number", "")
            foritflex = FortiFlex(
                username=FORTIFLEX_USERNAME,
                password=FORTIFLEX_PASSWORD,
                task_name="AZURE:" + self.instance_id,
            )
            if not (config_id and serial_number):
                entitlement = foritflex.get_entitlement(
                    FORTIFLEX_CONFIG_ID, description="AZURE:" + self.instance_id
                )
                if entitlement:
                    config_id = entitlement.get("configId", "")
                    serial_number = entitlement.get("serialNumber", "")
            if config_id and serial_number:
                foritflex.release_used_entitlement(
                    serial_number,
                    config_id,
                    mode=FORTIFLEX_RETRIEVE_MODE,
                    concurrent_mode=FORTIFLEX_CONCURRENT_MODE,
                )
        elif license_source == "file":  # Release license file
            status = self.file_license_release(instance_data)
            self.debug_print(f"Release instance with file {status}")
        self.debug_print(f"Release instance finished with method {license_source}")
        self.db.delete_document(self.instance_id)
        # If the global data is the only thing left behind, delete the whole dataset
        # If this instance is mater, reselect master.
        current_doc_number = self.db.get_document_number()
        delete_master = instance_data.get("is_master", False)
        if delete_master and current_doc_number > 1:
            status, reselect_master_id = self.reselect_master()
            self.debug_print(f"Reselect master {status} {reselect_master_id}")

    def file_license_assign(self):
        """
        Assign license for current instance, and return license data.
        """
        lock_status, global_data = self.db.lock("GLOBAL")
        if not lock_status or not isinstance(global_data, dict):
            return False, ""
        license_file_status = global_data.get("license_file_status")
        license_data = ""
        for license_file, owner_id in license_file_status.items():
            if owner_id == "":
                target_file = license_file
                license_file_status[license_file] = self.instance_id
                self.db.update_document(
                    "GLOBAL", {"license_file_status": license_file_status}
                )
                self.db.update_document(
                    self.instance_id,
                    {"license_file": target_file, "license_source": "file"},
                )
                license_data = download_license_file(target_file)
                break
        self.db.unlock("GLOBAL")
        return license_data != "", license_data

    def file_license_release(self, instance_data={}):
        if not instance_data:
            instance_data = self.db.get_document(self.instance_id)
            if not instance_data:
                return False
        license_file = instance_data.get("license_file", "")
        self.db.update_document(self.instance_id, {"license_file": ""})
        if license_file:
            lock_status, global_data = self.db.lock("GLOBAL")
            if not lock_status or not isinstance(global_data, dict):
                return False
            license_file_status = global_data.get("license_file_status", {})
            license_file_status[license_file] = ""
            self.db.update_document(
                "GLOBAL", {"license_file_status": license_file_status}
            )
            self.db.unlock("GLOBAL")
        return True

    def reselect_master(self):
        """
        If master instance is destroyed, reselect a new master based on created time.
        """
        lock_status, global_data = self.db.lock("GLOBAL")
        if not lock_status or not isinstance(global_data, dict):
            return False, ""

        instance_with_least_time = ""
        primary_sync_ip = ""
        least_time = float("+inf")
        docs = self.db.get_all_documents()
        for instance_id, instance_info in docs.items():
            if instance_id == "GLOBAL":
                continue
            instance_creation_time = instance_info.get("timestamp", float("+inf"))
            instance_creation_time = float(instance_creation_time)
            if instance_creation_time < least_time:
                least_time = instance_creation_time
                instance_with_least_time = instance_id
        if instance_with_least_time:
            instance_data = self.db.get_document(instance_with_least_time)
            primary_sync_ip = instance_data.get("private_ip", "")
            self.db.update_document(
                "GLOBAL",
                {
                    "primary_instance_id": instance_with_least_time,
                    "primary_sync_ip": primary_sync_ip,
                },
            )
            self.db.update_document(instance_with_least_time, {"is_master": True})
        self.db.unlock("GLOBAL")
        # reupload config
        if instance_with_least_time:
            for instance_id, instance_info in docs.items():
                if instance_id == "GLOBAL":
                    continue
                management_ip = instance_info.get("management_ip", "")
                instance_id = instance_info.get("instance_id", "")
                is_master = instance_with_least_time == instance_id
                config_module = FortiGateConfig(
                    management_ip,
                    "ReselectMaster-" + instance_id,
                    login_port=MANAGEMENT_PORT,
                    debug=PRINT_DEBUG_INFO,
                    username=FORTIGATE_INSTANCE_USER_NAME,
                    password=FORTIGATE_INSTANCE_PASSWORD,
                )
                config_data = config_system_autoscale(
                    is_master, primary_sync_ip, AUTOSCALE_PSKSECRET
                )
                self.debug_print(
                    f"config auto-scaling for {instance_id}, primary? {is_master}: {config_data}"
                )
                status, response = config_module.upload_config(config_data)
                self.debug_print("upload config %s, %s" % (status, response))
                if status:
                    self.db.update_document(instance_id, {"auto-scale": True})
        return instance_with_least_time != "", instance_with_least_time

    def debug_print(self, print_str):
        debug_print(f"[{self.instance_id}] " + print_str.replace("\n", "\\n"))


def config_system_autoscale(is_master, primary_sync_ip, AUTOSCALE_PSKSECRET):
    assert primary_sync_ip, "primary sync ip should not be valid"
    config_data = f"config system auto-scale\n"
    config_data += f"    set status enable\n"
    config_data += f"    set sync-interface port2\n"
    if is_master:
        config_data += f"    set role primary\n"
    else:
        config_data += f"    set role secondary\n"
        config_data += f"    set primary-ip {primary_sync_ip}\n"
    config_data += f"    set psksecret '{AUTOSCALE_PSKSECRET}'\n"
    config_data += f"end\n"
    return config_data
